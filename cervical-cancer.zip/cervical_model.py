
import tkinter as tk
from tkinter import messagebox
import numpy as np
import joblib

# Load the trained model

model = joblib.load("C:/Users/Saini/Desktop/dataset/cancer1.joblib")

# Function to make predictions
def predict_cancer():
    try:
        # Retrieve input values
        features = []
        for entry in entries:
            value = entry.get().strip()
            if value == "":
                messagebox.showerror("Input Error", "All fields must be filled.")
                return
            features.append(float(value))  # Convert to float

        # Prepare input array
        features_array = np.array(features).reshape(1, -1)
        
        # Make prediction
        prediction = model.predict(features_array)[0]
        result_text = "Positive for Cancer" if prediction == 1 else "Not Cancer"
        result_label.config(text=f"Prediction: {result_text}", fg="red" if prediction == 1 else "#2a2b2e")

    except ValueError:
        messagebox.showerror("Input Error", "Please enter valid numeric values.")

# Create main window
app = tk.Tk()
app.title("Cervical_Cancer Prediction")
app.config(bg="#63b995")
app.geometry("750x850")

# Title Label
title_label = tk.Label(app, text="Cervical_Cancer Prediction", font=("Arial", 20, "bold"), bg="#63b995", fg="#2a2b2e")
title_label.pack(pady=10)

# Feature labels and entry fields
feature_names = [
    "Age", "Number of sexual partners", "Number of pregnancies", "Years of smoking", 
    "Packs of cigarettes per year", "Using hormonal contraceptives (1=Yes, 0=No)",
    "Years using hormonal contraceptives", "Using IUD (1=Yes, 0=No)", "Years using IUD",
    "History of STDs: condylomatosis (1=Yes, 0=No)", "History of STDs: syphilis (1=Yes, 0=No)", 
    "History of STDs: pelvic inflammatory disease (1=Yes, 0=No)", "History of STDs: genital herpes (1=Yes, 0=No)",
    "History of STDs: AIDS (1=Yes, 0=No)", "History of STDs: HIV (1=Yes, 0=No)", 
    "History of STDs: Hepatitis B (1=Yes, 0=No)", "History of STDs: HPV (1=Yes, 0=No)",
    "Number of STD diagnoses", "Previous cancer diagnosis? (1=Yes, 0=No)"
]

entries = []
input_frame = tk.Frame(app, bg="#63b995")
input_frame.pack(pady=10)

for feature in feature_names:
    row_frame = tk.Frame(input_frame, bg="#63b995")
    row_frame.pack(fill="x", padx=20, pady=2)
    label = tk.Label(row_frame, text=feature, font=("Arial", 12,"bold"), bg="#63b995", fg="#2a2b2e", width=40, anchor="w")
    label.pack(side="left")
    entry = tk.Entry(row_frame, width=10)
    entry.pack(side="right")
    entries.append(entry)

# Predict button
predict_button = tk.Button(app, text="Predict", font=("Arial" ,14, "bold"), bg="#2a2b2e", fg="#63b995", command=predict_cancer)
predict_button.place(x=140,y=650)

# Result label
result_label = tk.Label(app, text="", font=("Arial", 14, "bold"), bg="#63b995", fg="#2a2b2e")
result_label.place(x=250,y=655)

# Run the GUI
app.mainloop()
