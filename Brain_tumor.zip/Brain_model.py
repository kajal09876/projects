import tkinter as tk
from tkinter import *
import cv2
import numpy as np
import joblib
from PIL import Image, ImageTk
from tkinter import filedialog

# Load trained model
model = joblib.load("C:/Users/Saini/Desktop/dataset/Br̥ain_tumor.joblib")

# Class labels
desc = {1: "Positive - Tumor Detected", 0: "Negative - No Tumor"}

# Function to classify uploaded image
def classify_image():
    global img_label
    file_path = filedialog.askopenfilename(filetypes=[("C:/Users/Saini/Desktop/dataset/Testing/", "*.jpg;*.png;*.jpeg")])
    
    if not file_path:
        return  # If no file is selected, do nothing

    # Read and preprocess image (Use selected file_path)
    img = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)  # Convert to grayscale
    img = cv2.resize(img, (200, 200))  # Resize to match model input
    img1 = img.reshape(1, -1) / 255  

    # Predict using the trained model
    p = model.predict(img1)

    # Display the image
    img = Image.open(file_path)
    img = img.resize((200, 200))
    img = ImageTk.PhotoImage(img)

    img_label.config(image=img)
    img_label.image = img

    # Update prediction label
    result_label.config(text=f"Prediction:{desc[p[0]]}",fg="pink" if p[0] == 1 else "#eba29d")

# Create GUI window
app = Tk()
app.geometry("800x550")
app.config(bg="#c92461")
app.title("Brain Tumor Detector")

# Heading
heading = Label(app, text="Brain Tumor Detection", font="robot 35 bold", fg="#59142d", bg="#c92461", pady=10)
heading.pack(fill="x")

# Upload button
upload_button = tk.Button(app, text="Upload MRI Image", font="Arial 18 bold", width="20", fg="#c92461", bg="#59142d", bd=6, command=classify_image)
upload_button.pack(pady=20)

# Image display label
img_label = tk.Label(app)
img_label.pack()

# Result display label
result_label = tk.Label(app, text="Prediction: ", font="Arial 18 bold", width="30", fg="#59142d", bg="#c92461")
result_label.pack(pady=20)

app.mainloop()
